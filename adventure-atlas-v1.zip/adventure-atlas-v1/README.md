# Adventure Atlas

Discover the places most people never find.

Adventure Atlas is a curated map of lesser-known outdoor adventures across the United States.

## What this first version includes

- Premium landing layout
- Search
- Adventure category filters
- Map-style interface
- Clickable pins
- Spot detail cards
- Premium locked spot preview
- Favorites
- Submit-a-spot form
- Mobile-friendly design

## How to run later on a computer

```bash
npm install
npm run dev
```

## How to deploy

Connect this repository to Vercel and use:

- Build command: `npm run build`
- Output directory: `dist`

## Important

This first version uses a custom map-style visual instead of a real Mapbox map.
The next upgrade is connecting real map tiles using Mapbox or MapLibre.
