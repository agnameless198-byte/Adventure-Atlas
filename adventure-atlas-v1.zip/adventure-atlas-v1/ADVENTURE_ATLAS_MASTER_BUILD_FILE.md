# Adventure Atlas Master Build File

This repository is the beginning of Adventure Atlas: a curated U.S. adventure map for hidden outdoor places.

Core idea:

> Discover the places most people never find.

Focus:
- swimming holes
- waterfalls
- rope swings
- hidden beaches
- camping
- scenic views
- road trip stops

Design:
- premium
- simple
- outdoorsy
- not cluttered
- mobile-first

Next steps:
1. Upload this project to GitHub.
2. Connect GitHub to Vercel.
3. Deploy the app.
4. Add real map provider.
5. Add real database.
