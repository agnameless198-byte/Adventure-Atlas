
import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Search, MapPin, Lock, Star, Heart, Navigation, AlertTriangle, SlidersHorizontal, Mountain, Waves, Tent, Camera, Droplets } from "lucide-react";
import spots from "./data/spots.json";
import "./styles.css";

const categories = [
  { name: "All", icon: Mountain },
  { name: "Swimming", icon: Droplets },
  { name: "Rope Swing", icon: Waves },
  { name: "Waterfall", icon: Droplets },
  { name: "Hidden Beach", icon: Waves },
  { name: "Camping", icon: Tent },
  { name: "Scenic View", icon: Camera },
];

function categoryIcon(name) {
  const found = categories.find(c => c.name === name);
  return found?.icon || MapPin;
}

function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [selected, setSelected] = useState(spots[0]);
  const [favorites, setFavorites] = useState([]);
  const [premiumPreview, setPremiumPreview] = useState(false);

  const filtered = useMemo(() => {
    return spots.filter((spot) => {
      const q = query.toLowerCase().trim();
      const matchesCategory = category === "All" || spot.category === category;
      const blob = `${spot.name} ${spot.state} ${spot.region} ${spot.category} ${spot.tags.join(" ")} ${spot.summary}`.toLowerCase();
      return matchesCategory && (!q || blob.includes(q));
    });
  }, [query, category]);

  function toggleFavorite(id) {
    setFavorites((prev) => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  function isLocked(spot) {
    return spot.premium && !premiumPreview;
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brandMark"><Mountain size={20}/></div>
          <div>
            <strong>Adventure Atlas</strong>
            <span>Curated outdoor places</span>
          </div>
        </div>
        <button className="premiumBtn" onClick={() => setPremiumPreview(!premiumPreview)}>
          {premiumPreview ? "Premium On" : "Preview Premium"}
        </button>
      </header>

      <main className="shell">
        <section className="hero">
          <p className="eyebrow">United States · V1</p>
          <h1>Discover the places most people never find.</h1>
          <p className="sub">
            A curated map of hidden swimming holes, waterfalls, rope swings, campsites, scenic overlooks, and outdoor adventures.
          </p>
        </section>

        <section className="mapLayout">
          <aside className="sidebar">
            <div className="searchBox">
              <Search size={18}/>
              <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search swimming, Utah, sunset..." />
            </div>

            <div className="filtersTitle">
              <SlidersHorizontal size={17}/>
              <span>Adventure Type</span>
            </div>

            <div className="chips">
              {categories.map((cat) => {
                const Icon = cat.icon;
                return (
                  <button key={cat.name} onClick={() => setCategory(cat.name)} className={category === cat.name ? "chip active" : "chip"}>
                    <Icon size={15}/>
                    {cat.name}
                  </button>
                );
              })}
            </div>

            <div className="resultCount">{filtered.length} places found</div>

            <div className="spotList">
              {filtered.map((spot) => {
                const locked = isLocked(spot);
                return (
                  <button key={spot.id} className={selected?.id === spot.id ? "spot activeSpot" : "spot"} onClick={() => setSelected(spot)}>
                    <div>
                      <strong>{spot.name}</strong>
                      <span>{spot.category} · {spot.state}</span>
                    </div>
                    {locked ? <Lock size={16}/> : <Star size={16}/>}
                  </button>
                );
              })}
            </div>
          </aside>

          <section className="mapCard">
            <div className="fakeMap">
              <div className="usaLabel">Adventure Atlas Map</div>
              {filtered.map((spot, index) => {
                const locked = isLocked(spot);
                const left = 15 + ((index * 17) % 70);
                const top = 20 + ((index * 23) % 55);
                const Icon = categoryIcon(spot.category);
                return (
                  <button 
                    key={spot.id}
                    className={selected?.id === spot.id ? "pin selectedPin" : locked ? "pin lockedPin" : "pin"}
                    style={{ left: `${left}%`, top: `${top}%` }}
                    onClick={() => setSelected(spot)}
                    title={spot.name}
                  >
                    {locked ? <Lock size={15}/> : <Icon size={15}/>}
                  </button>
                );
              })}
            </div>

            {selected && (
              <SpotDetails
                spot={selected}
                locked={isLocked(selected)}
                favorite={favorites.includes(selected.id)}
                toggleFavorite={() => toggleFavorite(selected.id)}
              />
            )}
          </section>
        </section>

        <section className="submitPanel">
          <div>
            <p className="eyebrow">Community growth</p>
            <h2>Know a place worth adding?</h2>
            <p>Adventure Atlas should grow through curated submissions, not random scraping. Every place should be public-access, useful, and worth the trip.</p>
          </div>
          <form className="submitForm" onSubmit={(e)=>e.preventDefault()}>
            <input placeholder="Spot name" />
            <input placeholder="State" />
            <select>
              <option>Swimming</option>
              <option>Rope Swing</option>
              <option>Waterfall</option>
              <option>Hidden Beach</option>
              <option>Camping</option>
              <option>Scenic View</option>
            </select>
            <textarea placeholder="What makes this place special?"></textarea>
            <button>Submit for review</button>
          </form>
        </section>
      </main>
    </div>
  );
}

function SpotDetails({ spot, locked, favorite, toggleFavorite }) {
  return (
    <article className="detailCard">
      <div className="detailTop">
        <div>
          <p className="eyebrow">{spot.category}</p>
          <h2>{spot.name}</h2>
          <p className="muted">{spot.region} · {spot.state}</p>
        </div>
        <button className={favorite ? "heart saved" : "heart"} onClick={toggleFavorite}><Heart size={20}/></button>
      </div>

      {locked ? (
        <div className="lockedBox">
          <Lock size={18}/>
          <div>
            <strong>Premium spot locked</strong>
            <p>Turn on Preview Premium to reveal exact coordinates and full detail layout.</p>
          </div>
        </div>
      ) : (
        <>
          <p className="summary">{spot.summary}</p>
          <p className="details">{spot.details}</p>

          <div className="stats">
            <span>Difficulty <strong>{spot.difficulty}</strong></span>
            <span>Crowd <strong>{spot.crowd}</strong></span>
            <span>Score <strong>{spot.adventureScore}/10</strong></span>
          </div>

          <div className="coords">
            <Navigation size={16}/>
            <span>{spot.lat}, {spot.lng}</span>
          </div>

          <div className="warnings">
            <div className="warningTitle"><AlertTriangle size={16}/> Safety Notes</div>
            {spot.warnings.map((warning) => <span key={warning}>{warning}</span>)}
          </div>
        </>
      )}
    </article>
  );
}

createRoot(document.getElementById("root")).render(<App />);
